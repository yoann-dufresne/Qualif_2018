from solution import Solution


def solve (problem):
	cars = [(0, 0, 0) for _ in range(problem[2])]

	return Solution(problem[2])


